package com.example.wms.entities;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.net.ProtocolFamily;

@Getter
@Setter
@Entity
@Table(name="roles")
public class Role {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Enumerated(EnumType.STRING)
    @Column(unique = true ,nullable = false)
    private RoleName name;


}